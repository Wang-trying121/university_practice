#include "Gate.h"
#include<iostream>
Gate::Gate ():
inputa(false),inputb(false),output(false) ,inputsourceA(nullptr), inputsourceB(nullptr),faultType(0) {}
Gate::~Gate() {}

void Gate::connectSourceA(Gate* source) {
	inputsourceA = source;
}
void Gate::connectSourceB(Gate* source) {
	inputsourceB = source;
}
bool Gate::getRealA() {
	if(inputsourceA == nullptr) {//û�����߾���Ĭ��ֵ
		return inputa;
	} else {
		inputsourceA->evaluate();//����������һ����������
		return inputsourceA->getOutput();
	}
}
bool Gate::getRealB() {
	if(inputsourceB == nullptr) {
		return inputb;
	} else {
		inputsourceB->evaluate();
		return inputsourceB->getOutput();
	}
}
bool Gate::ifsourceGate(){
	//�ж�����A�Ƿ�Ϊ��
	if (inputsourceA == nullptr){
		return 1;
	} else{
		return 0;
	}
	 
}
void Gate::setInput(bool a,bool b) {
	inputa = a;//����Ĭ��ֵ
	inputb = b;
}
bool Gate::getOutput() {
	if (faultType == 0){
		return output;
	} else if(faultType == 1){
		return 0;
	}else if (faultType == 2){
		return 1;
	}else{
		return output;
	}
}
void AndGate::evaluate(){
	output = getRealA()&&getRealB();
}
void OrGate::evaluate(){
	output = getRealA()||getRealB();
}
void NotGate::evaluate(){
	output = !getRealA();
}
void XorGate::evaluate(){
	output = !(getRealA() == getRealB());
}
void AorGate::evaluate(){
	output = (getRealA() == getRealB());
}
