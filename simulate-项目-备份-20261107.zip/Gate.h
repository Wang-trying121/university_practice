#ifndef GATES_H
#define GATES_H
#include <string> 

class Gate {
protected:
    bool inputa;
    bool inputb;
    bool output;
    Gate* inputsourceA;
    Gate* inputsourceB;

public:
    virtual ~Gate();  // �������������˺�
    Gate();
    
    void connectSourceA(Gate* source);
    void connectSourceB(Gate* source);
    Gate* getSourceA(){return inputsourceA;}
    Gate* getSourceB(){return inputsourceB;}
    
    bool getRealA();
    bool getRealB();
    bool ifsourceGate();
    
    void setInput(bool a, bool b);
    bool getOutput();
    std::string name;
    int faultType;
    virtual void evaluate() = 0;
}; // ����Ҫ�зֺ�

class AndGate : public Gate { // ��Ҫ����
public:
    void evaluate() override;
}; 

class OrGate : public Gate {
public:
    void evaluate() override;
}; // ����Ҫ�зֺ�

class XorGate : public Gate { // ����ĸ��д
public:
    void evaluate() override;
};

class NotGate : public Gate {
public:
    void evaluate() override;
};

class AorGate : public Gate {
public:
    void evaluate() override;
};

#endif
